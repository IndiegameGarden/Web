using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MandelShader
{
    public class MandelGame : Game
    {
        GraphicsDeviceManager graphicsMgr;

        SpriteBatch spriteBatch;
        SpriteFont font1;
        Rectangle screenRect;

        Effect mandelbrotEffect;
        Texture2D dummyTexture;
        float aspectRatio;

        Vector2 pan = new Vector2(0.25f, 0.000f);
        Vector2 juliaSeed = new Vector2(0.39f, -0.2f);
        Vector3 colorScale = new Vector3(4, 5, 6);
        float zoom = 3;
        int iterations = 128;

        // speeds of keyboard navigation
        float moveSpeed = 0.003f;
        float zoomSpeed = 0.008f;
        float juliaSeedSpeed = 0.0001f;

        public MandelGame()
        {
            // setup the preferences for the GraphicsDevice that's going to be created
            graphicsMgr = new GraphicsDeviceManager(this);
            graphicsMgr.PreferredBackBufferWidth = 1024;
            graphicsMgr.PreferredBackBufferHeight = 768;
            graphicsMgr.IsFullScreen = true;
#if PROFILE
            graphicsMgr.SynchronizeWithVerticalRetrace = false; // for profiling FPS, try to run as fast as possible
            this.IsFixedTimeStep = false;
#endif
        }

        protected override void Initialize()
        {
            Content.RootDirectory = "Content";

            // add a framerate counter on screen
            Components.Add(new FrameRateCounter(this, 512f, 0f));

            screenRect = new Rectangle(0, 0, graphicsMgr.GraphicsDevice.DisplayMode.Width, graphicsMgr.GraphicsDevice.DisplayMode.Height);
            aspectRatio = (float)GraphicsDevice.Viewport.Height / (float)GraphicsDevice.Viewport.Width; // Note the unusual aspect ratio def.

            base.Initialize();

        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            font1 = Content.Load<SpriteFont>("SpriteFont1");
            mandelbrotEffect = Content.Load<Effect>("MandelbrotJulia");
            dummyTexture = new Texture2D(graphicsMgr.GraphicsDevice,
                graphicsMgr.GraphicsDevice.Viewport.Width,
                graphicsMgr.GraphicsDevice.Viewport.Height,
                false, SurfaceFormat.Color);

            // vertex shader init, see .fx file and http://forums.create.msdn.com/forums/p/71866/438467.aspx
            Viewport viewport = GraphicsDevice.Viewport;
            Matrix projection = Matrix.CreateOrthographicOffCenter(0, viewport.Width, viewport.Height, 0, 0, 1);
            Matrix halfPixelOffset = Matrix.CreateTranslation(-0.5f, -0.5f, 0);
            mandelbrotEffect.Parameters["MatrixTransform"].SetValue(halfPixelOffset * projection);

        }

        protected override void UnloadContent()
        {
            base.UnloadContent();
        }

        
        protected override void Update(GameTime gameTime)
        {
            KeyboardState keyboardState = Keyboard.GetState();

            // Allows the game to exit (ESC on Windows)
            if (keyboardState.IsKeyDown(Keys.Escape) || GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // perform all keyboard functions
            float slowFactor = 1f;
            if (keyboardState.IsKeyDown(Keys.LeftShift) || keyboardState.IsKeyDown(Keys.RightShift)) 
                                                        slowFactor = 0.1f;    // if SHIFT is pressed, things move more slowly!
            if (keyboardState.IsKeyDown(Keys.Up))       pan.Y += (slowFactor * moveSpeed * zoom);
            if (keyboardState.IsKeyDown(Keys.Down))     pan.Y -= (slowFactor * moveSpeed * zoom);
            if (keyboardState.IsKeyDown(Keys.Left))     pan.X += (slowFactor * moveSpeed * zoom);
            if (keyboardState.IsKeyDown(Keys.Right))    pan.X -= (slowFactor * moveSpeed * zoom);            
            if (keyboardState.IsKeyDown(Keys.PageUp))   zoom /= (1f + slowFactor * zoomSpeed);
            if (keyboardState.IsKeyDown(Keys.PageDown)) zoom *= (1f + slowFactor * zoomSpeed);
            if (keyboardState.IsKeyDown(Keys.I))        iterations++;            
            if (keyboardState.IsKeyDown(Keys.O))        iterations--;            
            if (keyboardState.IsKeyDown(Keys.J))        mandelbrotEffect.CurrentTechnique = mandelbrotEffect.Techniques[1];
            if (keyboardState.IsKeyDown(Keys.M))        mandelbrotEffect.CurrentTechnique = mandelbrotEffect.Techniques[0];
            if (keyboardState.IsKeyDown(Keys.D7))       juliaSeed.X -= slowFactor * juliaSeedSpeed;
            if (keyboardState.IsKeyDown(Keys.D8))       juliaSeed.X += slowFactor * juliaSeedSpeed;
            if (keyboardState.IsKeyDown(Keys.D9))       juliaSeed.Y -= slowFactor * juliaSeedSpeed;
            if (keyboardState.IsKeyDown(Keys.D0))       juliaSeed.Y += slowFactor * juliaSeedSpeed;

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            // set the relevant fractal params into the HLSL effect, before drawing
            mandelbrotEffect.Parameters["Pan"].SetValue(pan);
            mandelbrotEffect.Parameters["Zoom"].SetValue(zoom);
            mandelbrotEffect.Parameters["Aspect"].SetValue(aspectRatio);
            mandelbrotEffect.Parameters["Iterations"].SetValue(iterations);
            mandelbrotEffect.Parameters["JuliaSeed"].SetValue(juliaSeed);

            // draw the fractal
            spriteBatch.Begin(SpriteSortMode.Immediate, BlendState.Opaque, null, null, null, mandelbrotEffect);
            spriteBatch.Draw(dummyTexture, Vector2.Zero, Color.White);
            spriteBatch.End();

            // draw the text listing the 'iterations' parameter
            spriteBatch.Begin();
            String IterationText = "Iterations : " + iterations;
            Vector2 FontOrigin = font1.MeasureString(IterationText) / 2;
            spriteBatch.DrawString(font1, IterationText, new Vector2(10, 10) + FontOrigin, Color.Green,
                0, FontOrigin, 1.0f, SpriteEffects.None, 0.5f);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}

