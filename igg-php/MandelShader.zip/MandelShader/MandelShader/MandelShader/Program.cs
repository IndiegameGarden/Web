using System;
using Microsoft.Xna.Framework;

namespace MandelShader
{
#if WINDOWS || XBOX
    static class Program
    {
        /// The main entry point for the application.
        static void Main(string[] args)
        {
            using (Game game = new MandelGame())
            {
                game.Run();
            }
        }
    }
#endif
}

